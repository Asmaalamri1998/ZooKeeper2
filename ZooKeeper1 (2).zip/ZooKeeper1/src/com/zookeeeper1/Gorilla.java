package com.zookeeeper1;

public class Gorilla extends Mammal {
	
	public Gorilla() {
		super();
	}
	
	public void throwSomething() {
		
		int energy = super.getEnergylevel();
		energy -=5;
		System.out.println(" the Gorilla has thrown something");
		super.setEnergylevel(energy);
		super.displayEnergy();
	}
	
	public void eatBananas() {
		int energy = super.getEnergylevel();
		energy +=10;
		System.out.println(" the Gorilla has eat banana");
		super.setEnergylevel(energy);
		super.displayEnergy();
	}
	
	public void climb() {
		int energy = super.getEnergylevel();
		energy-=10;
		System.out.println(" the Gorilla has climb ");
		super.setEnergylevel(energy);
		super.displayEnergy();
	}
	

}
