package com.zookeeeper1;

public class Bat extends Mammal {
	
	public Bat() {
		super();
		this.setEnergylevel(300);
	}

	public void  fly() {
		System.out.println(" the bat is flying now ");
		int energy = super.getEnergylevel();
		energy -=50;
		super.setEnergylevel(energy);
		super.displayEnergy();
		
	}
	
	public void eatHumans() {
		System.out.println(" eated a human ");
		int energy = super.getEnergylevel();
		energy+= 25;
		super.setEnergylevel(energy);
		super.displayEnergy();
	}
	public void attackTown() {
		System.out.println("the town attack");
		int energy = super.getEnergylevel();
		energy -=100;
		super.setEnergylevel(energy);
		super.displayEnergy();
	}
	
}
